#include <aes.h>
#include <modes.h>
#include <filters.h>
#include <hex.h>
#include <files.h>

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
#include <cctype>

using namespace CryptoPP;

// ---------------- Utility ----------------
static void trim(std::string &s) {
    size_t a = 0; while (a < s.size() && isspace((unsigned char)s[a])) ++a;
    size_t b = s.size(); while (b > a && isspace((unsigned char)s[b-1])) --b;
    s = s.substr(a, b - a);
}

// Convert hex string to raw bytes
std::string HexToBytes(const std::string& hex) {
    std::string decoded;
    StringSource(hex, true, new HexDecoder(new StringSink(decoded)));
    return decoded;
}

// Convert raw bytes to hex string
std::string BytesToHex(const byte* data, size_t len) {
    std::string encoded;
    StringSource(data, len, true, new HexEncoder(new StringSink(encoded), false));
    return encoded;
}

// Overload for convenience (when you have std::string)
std::string BytesToHex(const std::string& bytes) {
    return BytesToHex(reinterpret_cast<const byte*>(bytes.data()), bytes.size());
}


// ---------------- AES-CBC ----------------
// usePadding=true => PKCS_PADDING
// usePadding=false => NO_PADDING (using for KAT)
std::string AESEncrypt(const std::string& plaintext,
                       const byte key[], size_t keyLen,
                       const byte iv[], bool usePadding = true)
{
    std::string ciphertext;
    try {
        CBC_Mode<AES>::Encryption enc;
        enc.SetKeyWithIV(key, keyLen, iv);
        StringSource(plaintext, true,
            new StreamTransformationFilter(enc,
                new StringSink(ciphertext),
                usePadding ? BlockPaddingSchemeDef::PKCS_PADDING
                           : StreamTransformationFilter::NO_PADDING)
        );
    } catch (...) { return std::string(); }
    return ciphertext;
} 

std::string AESDecrypt(const std::string& ciphertext,
                       const byte key[], size_t keyLen,
                       const byte iv[], bool usePadding = true)
{
    std::string plaintext;
    try {
        CBC_Mode<AES>::Decryption dec;
        dec.SetKeyWithIV(key, keyLen, iv);
        StringSource(ciphertext, true,
            new StreamTransformationFilter(dec,
                new StringSink(plaintext),
                usePadding ? BlockPaddingSchemeDef::PKCS_PADDING
                           : StreamTransformationFilter::NO_PADDING)
        );
    } catch (...) { return std::string(); }
    return plaintext;
}

// ---------------- KAT ----------------
struct TestVector {
    int count = -1;
    std::string KEY, IV, PLAINTEXT, CIPHERTEXT;
};

static std::vector<TestVector> ParseRsp(const std::string& path) {
    std::string text;
    try { FileSource fs(path.c_str(), true, new StringSink(text)); }
    catch(...) { return {}; }
    std::istringstream iss(text);
    std::string line;
    std::vector<TestVector> list;
    TestVector cur;
    while (std::getline(iss, line)) {
        trim(line);
        if (line.empty() || line[0]=='#') continue;
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq), v = line.substr(eq+1);
        trim(k); trim(v);
        if (k == "COUNT") {
            if (cur.count != -1 && !cur.KEY.empty() && !cur.PLAINTEXT.empty())
                list.push_back(cur);
            cur = TestVector();
            cur.count = std::stoi(v);
        } else if (k == "KEY") cur.KEY = v;
        else if (k == "IV") cur.IV = v;
        else if (k == "PLAINTEXT") cur.PLAINTEXT = v;
        else if (k == "CIPHERTEXT") cur.CIPHERTEXT = v;
    }
    if (cur.count != -1 && !cur.KEY.empty()) list.push_back(cur);
    return list;
}

static void RunKAT() {
    // Run Known-Answer Tests (KAT) using provided test vectors
    const std::string dir = "kat/";
    const std::vector<std::string> files = {
        "CBCVarKey128.rsp","CBCVarKey192.rsp","CBCVarKey256.rsp",
        "CBCVarTxt128.rsp","CBCVarTxt192.rsp","CBCVarTxt256.rsp"
    };

    std::ofstream csv("kat_results.csv");
    csv << "filename,COUNT,pass\n";
    long totalAll = 0, passAll = 0;

    for (auto& name : files) {
        std::string path = dir + name;
        std::ifstream chk(path);
        if (!chk.good()) continue;

        std::vector<TestVector> vecs = ParseRsp(path);
        long total=0, pass=0;
        for (auto& v : vecs) {
            ++total;
            // Convert hex strings to binary data for key, IV, plaintext, ciphertext
            std::string kat_key = HexToBytes(v.KEY);
            std::string kat_iv  = HexToBytes(v.IV);
            std::string kat_pt  = HexToBytes(v.PLAINTEXT);
            std::string kat_ct  = HexToBytes(v.CIPHERTEXT);

            const byte* key_ptr = reinterpret_cast<const byte*>(kat_key.data());
            const byte* iv_ptr  = reinterpret_cast<const byte*>(kat_iv.data());

            std::string ct = AESEncrypt(kat_pt, key_ptr, kat_key.size(), iv_ptr, false);
            std::string pt = AESDecrypt(kat_ct, key_ptr, kat_key.size(), iv_ptr, false);

            bool ok = (!ct.empty() && !pt.empty() && ct == kat_ct && pt == kat_pt);
            if (ok) ++pass;
            csv << name << "," << v.count << "," << (ok ? "1" : "0") << "\n";
        }
        double rate = total ? 100.0 * pass / total : 0.0;
        std::cout << path << ": " << pass << "/" << total
                  << " (" << std::fixed << std::setprecision(2) << rate << "%)\n";
        totalAll += total; passAll += pass;
    }

    double overall = totalAll ? 100.0 * passAll / totalAll : 0.0;
    std::cout << "\nOverall: " << passAll << "/" << totalAll
              << " (" << std::fixed << std::setprecision(2) << overall << "%)\n";
    std::cout << "Results written to kat_results.csv\n";
}

// ---------------- Interactive ----------------
static void Interactive() {
    std::cout << "AES-CBC Interactive Mode\n";
    while (true) {
        std::string keyHex, ivHex, plain;
        std::cout << "\nKey hex (16/24/32 bytes, empty to quit): ";
        if (!std::getline(std::cin, keyHex)) return;
        trim(keyHex);
        if (keyHex.empty()) return;

        std::cout << "IV hex (16 bytes, or empty for zeros): ";
        if (!std::getline(std::cin, ivHex)) return;
        trim(ivHex);

        std::cout << "Plaintext: ";
        if (!std::getline(std::cin, plain)) return;

        // Convert input hex to binary key and IV
        std::string key = HexToBytes(keyHex);
        std::string iv  = ivHex.empty() ? std::string(AES::BLOCKSIZE, 0) : HexToBytes(ivHex);

        const byte* key_ptr = reinterpret_cast<const byte*>(key.data());
        const byte* iv_ptr  = reinterpret_cast<const byte*>(iv.data());

        std::string ct = AESEncrypt(plain, key_ptr, key.size(), iv_ptr, true);
        std::cout << "Ciphertext (hex): " << BytesToHex(ct) << "\n";

        std::string pt = AESDecrypt(ct, key_ptr, key.size(), iv_ptr, true);
        std::cout << "Decrypted text: " << pt << "\n";
    }
}

// ---------------- main ----------------
int main(int argc, char** argv) {
    bool kat = false;
    for (int i=1; i<argc; ++i)
        if (std::string(argv[i]) == "--kat") kat = true;

    if (kat) RunKAT();
    else Interactive();
    return 0;
}
