#include <iostream>
#include <string>
#include <cryptlib.h>
#include <hex.h>
#include <filters.h>
#include <aes.h>
#include <modes.h>
#include <osrng.h>

using namespace CryptoPP;

void GenerateAESKey(byte key[], byte iv[]) {
    AutoSeededRandomPool prng;
    prng.GenerateBlock(key, AES::DEFAULT_KEYLENGTH);  // Generate 16-byte AES key
    prng.GenerateBlock(iv, AES::BLOCKSIZE);          // Generate 16-byte IV
}

std::string AESEncrypt(const std::string& plaintext, const byte key[], const byte iv[]) {
    std::string ciphertext;

    try {
        CBC_Mode<AES>::Encryption encryptor;
        encryptor.SetKeyWithIV(key, AES::DEFAULT_KEYLENGTH, iv);

        StringSource(plaintext, true,
            new StreamTransformationFilter(encryptor,
                new StringSink(ciphertext),
                BlockPaddingSchemeDef::PKCS_PADDING
            )
        );
    } catch (const Exception& e) {
        std::cerr << "Encryption Error: " << e.what() << std::endl;
    }

    return ciphertext;
}

std::string AESDecrypt(const std::string& ciphertext, const byte key[], const byte iv[]) {
    std::string decryptedText;

    try {
        CBC_Mode<AES>::Decryption decryptor;
        decryptor.SetKeyWithIV(key, AES::DEFAULT_KEYLENGTH, iv);

        StringSource(ciphertext, true,
            new StreamTransformationFilter(decryptor,
                new StringSink(decryptedText),
                BlockPaddingSchemeDef::PKCS_PADDING
            )
        );
    } catch (const Exception& e) {
        std::cerr << "Decryption Error: " << e.what() << std::endl;
    }

    return decryptedText;
}

void PrintHex(const std::string& label, const std::string& data) {
    std::string encoded;
    StringSource(data, true, new HexEncoder(new StringSink(encoded)));
    std::cout << label << encoded << std::endl;
}

int main() {
    byte key[AES::DEFAULT_KEYLENGTH], iv[AES::BLOCKSIZE];
    GenerateAESKey(key, iv);

    std::string plaintext = "Crypto++ AES CBC Test";
    std::cout << "Original Text: " << plaintext << std::endl;

    std::string ciphertext = AESEncrypt(plaintext, key, iv);
    PrintHex("Ciphertext (Hex): ", ciphertext);

    std::string decryptedText = AESDecrypt(ciphertext, key, iv);
    std::cout << "Decrypted Text: " << decryptedText << std::endl;

    return 0;
}
